#ifndef MIDI_USB_H
#define MIDI_USB_H

#ifdef __cplusplus
extern "C" {
#endif 

#include "midi.h"

void midi_usb_init(MidiDevice * device);

#ifdef __cplusplus
}
#endif 

#endif
